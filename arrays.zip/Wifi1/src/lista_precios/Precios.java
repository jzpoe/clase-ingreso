/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lista_precios;

/**
 *
 * @author Jz
 */
public class Precios {
    
    String verduras;
    String carne;
    String medicina;

    public Precios(String verduras, String carne, String medicina) {
        this.verduras = verduras;
        this.carne = carne;
        this.medicina = medicina;
    }

    public Precios() {
    }

    public String getVerduras() {
        return verduras;
    }

    public void setVerduras(String verduras) {
        this.verduras = verduras;
    }

    public String getCarne() {
        return carne;
    }

    public void setCarne(String carne) {
        this.carne = carne;
    }

    public String getMedicina() {
        return medicina;
    }

    public void setMedicina(String medicina) {
        this.medicina = medicina;
    }
    
    
}
